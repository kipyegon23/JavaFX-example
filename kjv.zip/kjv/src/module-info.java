module kjv {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.cyrus.kjv to javafx.fxml;
    exports com.cyrus.kjv;
}