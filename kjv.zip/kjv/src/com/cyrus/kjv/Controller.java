
package com.cyrus.kjv;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.TreeMap;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;


public class Controller {
    @FXML
    private TextArea contentTextArea = new TextArea();
    @FXML
    private ListView<String> booksListView = new ListView<String>();
    @FXML
    private TextField searchTextField = new TextField();

    private TreeMap<String, String> contents = new TreeMap<>();



    public void initialize() throws IOException {
        File folder = new File(System.getProperty("user.dir"), "files");
        File[] fileList = folder.listFiles();
        for (int i=0; i<fileList.length; i++){

            String k = fileList[i].getName().replace(".txt", "");
//            List<String> v = Files.readAllLines(Path.of("files", fileList[i].getName()));
            String v = Files.readString(Path.of("files", fileList[i].getName()));
            contents.put(k, v.toString());
        }

        booksListView.getItems().setAll(contents.keySet());
        booksListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);


    }
  public String handleTextSearch() {
    return "cyrus";

    }

    @FXML
    public void handleBookListView(){
        String book = booksListView.getSelectionModel().getSelectedItem();
        contentTextArea.setText(contents.get(book));


    }

}